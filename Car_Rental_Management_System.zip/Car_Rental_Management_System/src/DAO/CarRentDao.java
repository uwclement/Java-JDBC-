/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.*;
import javax.management.Query;

/**
 *
 * @author CTRL-SHIFT Ltd
 */
public class CarRentDao {
            String durl="jdbc:mysql://localhost:3306/car_rental_management_system_db";
        String usernmae ="root";
        String pssrd ="";

    public CarRentDao() {

    }
    public String registercustomer()
    {
        try {
            Connection con =DriverManager.getConnection(durl, usernmae, pssrd);
            PreparedStatement pst =con.prepareStatement("insert into customer (customer_id,firstname,lastname,phone,email,address) values(?,?,?,?,?,?)");
            int rowAffected = pst.executeUpdate();
            if(rowAffected>=1){
            return "Customer Registered";
            }else
            {
            return "Customer not Registered";
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    return "Server Error";
    }
}
